// src/navigation/AppNavigator.js
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/App/HomeScreen';
import TaskListScreen from '../screens/App/TaskListScreen'; 
import AddTaskScreen from '../screens/App/AddTaskScreen';
import EditTaskScreen from '../screens/App/EditTaskScreen';
// Placeholder for Pomodoro screen
// import PomodoroScreen from '../screens/App/PomodoroScreen';

const Stack = createNativeStackNavigator();

// Placeholder screen for now
const PomodoroScreen = () => <View><Text>Pomodoro Screen (WIP)</Text></View>;

const AppNavigator = () => {
  return (
    <Stack.Navigator initialRouteName="Home">
      <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Início' }} />
      <Stack.Screen name="TaskList" component={TaskListScreen} options={{ title: 'Minhas Tarefas' }} />
      <Stack.Screen name="AddTask" component={AddTaskScreen} options={{ title: 'Adicionar Tarefa' }} />
      <Stack.Screen name="EditTask" component={EditTaskScreen} options={{ title: 'Editar Tarefa' }} />
      <Stack.Screen name="Pomodoro" component={PomodoroScreen} options={{ title: 'Timer Pomodoro' }} />
    </Stack.Navigator>
  );
};

// Temporary placeholder components until actual screens are built
import { View, Text } from 'react-native';

export default AppNavigator;

