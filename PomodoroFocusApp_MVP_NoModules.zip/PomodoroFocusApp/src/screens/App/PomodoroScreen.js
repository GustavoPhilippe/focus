// src/screens/App/PomodoroScreen.js
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Button, StyleSheet, Alert, AppState } from 'react-native';
// Consider adding a notification library later for background notifications
// import PushNotification from 'react-native-push-notification';

const FOCUS_TIME = 25 * 60; // 25 minutes in seconds
const BREAK_TIME = 5 * 60;  // 5 minutes in seconds

const PomodoroScreen = () => {
  const [timer, setTimer] = useState(FOCUS_TIME);
  const [isActive, setIsActive] = useState(false);
  const [isFocusMode, setIsFocusMode] = useState(true); // true for focus, false for break
  const intervalRef = useRef(null);
  const appState = useRef(AppState.currentState);
  const backgroundTimestamp = useRef(null);

  // Handle AppState changes for background timer accuracy
  useEffect(() => {
    const subscription = AppState.addEventListener('change', nextAppState => {
      if (appState.current.match(/inactive|background/) && nextAppState === 'active') {
        console.log('App has come to the foreground!');
        // Calculate time spent in background
        if (backgroundTimestamp.current && isActive) {
          const timeInBackground = Math.floor((Date.now() - backgroundTimestamp.current) / 1000);
          setTimer(prevTimer => Math.max(0, prevTimer - timeInBackground));
        }
        backgroundTimestamp.current = null; // Reset timestamp
      }

      if (nextAppState.match(/inactive|background/)) {
          console.log('App has gone to the background!');
          if (isActive) {
              backgroundTimestamp.current = Date.now();
          }
      }

      appState.current = nextAppState;
      console.log('AppState', appState.current);
    });

    return () => {
      subscription.remove();
    };
  }, [isActive]);

  useEffect(() => {
    if (isActive) {
      intervalRef.current = setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer <= 1) {
            clearInterval(intervalRef.current);
            setIsActive(false);
            handleTimerEnd();
            return 0;
          }
          return prevTimer - 1;
        });
      }, 1000);
    } else {
      clearInterval(intervalRef.current);
    }

    return () => clearInterval(intervalRef.current); // Cleanup on unmount or when isActive changes
  }, [isActive]);

  const handleTimerEnd = () => {
    // Basic alert, replace with proper notifications later
    Alert.alert(
      isFocusMode ? "Foco Concluído!" : "Descanso Concluído!",
      isFocusMode ? "Hora de uma pausa!" : "Hora de voltar ao foco!"
    );
    // Switch mode and reset timer
    setIsFocusMode(!isFocusMode);
    setTimer(isFocusMode ? BREAK_TIME : FOCUS_TIME);
  };

  const toggleTimer = () => {
    setIsActive(!isActive);
  };

  const resetTimer = () => {
    clearInterval(intervalRef.current);
    setIsActive(false);
    setIsFocusMode(true); // Reset to focus mode
    setTimer(FOCUS_TIME);
  };

  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  // --- Placeholder for time adjustment --- 
  // TODO: Add inputs or settings to change FOCUS_TIME and BREAK_TIME

  return (
    <View style={styles.container}>
      <Text style={styles.modeText}>{isFocusMode ? 'Modo Foco' : 'Modo Descanso'}</Text>
      <Text style={styles.timerText}>{formatTime(timer)}</Text>
      <View style={styles.buttonContainer}>
        <Button title={isActive ? 'Pausar' : 'Iniciar'} onPress={toggleTimer} />
        <Button title="Resetar" onPress={resetTimer} color="red" />
      </View>
      {/* Placeholder for task integration */}
      {/* <Text>Tarefa Atual: [Nome da Tarefa Selecionada]</Text> */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modeText: {
      fontSize: 24,
      fontWeight: 'bold',
      marginBottom: 10,
  },
  timerText: {
    fontSize: 80, // Larger font for the timer
    fontWeight: 'bold',
    marginBottom: 30,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '60%', // Adjust width as needed
  },
});

export default PomodoroScreen;

