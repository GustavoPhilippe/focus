// src/screens/App/AddTaskScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import auth from '@react-native-firebase/auth';

const AddTaskScreen = ({ navigation }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const currentUser = auth().currentUser;

  const handleAddTask = async () => {
    if (!title) {
      Alert.alert('Erro', 'O título da tarefa é obrigatório.');
      return;
    }
    if (!currentUser) {
        Alert.alert('Erro', 'Usuário não autenticado.');
        return;
    }

    setLoading(true);
    try {
      await firestore().collection('tasks').add({
        title,
        description,
        completed: false,
        userId: currentUser.uid, // Associate task with the logged-in user
        createdAt: firestore.FieldValue.serverTimestamp(), // Use server timestamp
      });
      console.log('Tarefa adicionada com sucesso!');
      Alert.alert('Sucesso', 'Tarefa adicionada!');
      navigation.goBack(); // Go back to the task list
    } catch (error) {
      console.error("Erro ao adicionar tarefa: ", error);
      Alert.alert('Erro', 'Não foi possível adicionar a tarefa.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Adicionar Nova Tarefa</Text>
      <TextInput
        style={styles.input}
        placeholder="Título da Tarefa *"
        value={title}
        onChangeText={setTitle}
      />
      <TextInput
        style={[styles.input, styles.textArea]}
        placeholder="Descrição (Opcional)"
        value={description}
        onChangeText={setDescription}
        multiline
      />
      {loading ? (
          <ActivityIndicator size="large" />
      ) : (
          <Button title="Adicionar Tarefa" onPress={handleAddTask} />
      )}
      <View style={{ marginTop: 10 }}>
        <Button title="Cancelar" onPress={() => navigation.goBack()} color="gray" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 45,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 15,
    paddingHorizontal: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  textArea: {
      height: 100, // Taller for multiline input
      textAlignVertical: 'top', // Align text to the top for multiline
  }
});

export default AddTaskScreen;

