// src/screens/App/TaskListScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Button, StyleSheet, ActivityIndicator, Alert, TouchableOpacity } from 'react-native';
import firestore from '@react-native-firebase/firestore';
import auth from '@react-native-firebase/auth';

// Placeholder for Add/Edit Task Screen Navigation
// import AddTaskScreen from './AddTaskScreen'; 
// import EditTaskScreen from './EditTaskScreen';

const TaskListScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [tasks, setTasks] = useState([]);
  const currentUser = auth().currentUser;

  useEffect(() => {
    if (!currentUser) {
      // Should not happen if RootNavigator is working, but good practice
      console.log("Usuário não autenticado acessando TaskListScreen");
      // Optionally navigate back to login
      // navigation.navigate('Login'); 
      setLoading(false);
      return;
    }

    const subscriber = firestore()
      .collection('tasks')
      .where('userId', '==', currentUser.uid) // Filter tasks by the logged-in user
      .orderBy('createdAt', 'desc') // Show newest tasks first
      .onSnapshot(querySnapshot => {
        const tasksData = [];
        querySnapshot.forEach(documentSnapshot => {
          tasksData.push({
            ...documentSnapshot.data(),
            id: documentSnapshot.id,
          });
        });
        setTasks(tasksData);
        setLoading(false);
      }, error => {
          console.error("Erro ao buscar tarefas: ", error);
          Alert.alert("Erro", "Não foi possível carregar as tarefas.");
          setLoading(false);
      });

    // Unsubscribe from events when no longer in use
    return () => subscriber();
  }, [currentUser]); // Rerun effect if user changes

  const toggleTaskCompletion = async (taskId, currentStatus) => {
    try {
      await firestore()
        .collection('tasks')
        .doc(taskId)
        .update({ completed: !currentStatus });
      console.log('Status da tarefa atualizado!');
    } catch (error) {
      console.error("Erro ao atualizar tarefa: ", error);
      Alert.alert("Erro", "Não foi possível atualizar o status da tarefa.");
    }
  };

  const deleteTask = (taskId) => {
      Alert.alert(
          "Confirmar Exclusão",
          "Tem certeza que deseja excluir esta tarefa?",
          [
              { text: "Cancelar", style: "cancel" },
              {
                  text: "Excluir",
                  onPress: async () => {
                      try {
                          await firestore().collection('tasks').doc(taskId).delete();
                          console.log('Tarefa excluída!');
                      } catch (error) {
                          console.error("Erro ao excluir tarefa: ", error);
                          Alert.alert("Erro", "Não foi possível excluir a tarefa.");
                      }
                  },
                  style: "destructive",
              },
          ]
      );
  };

  if (loading) {
    return <ActivityIndicator size="large" style={styles.loader} />;
  }

  const renderItem = ({ item }) => (
    <View style={styles.taskItem}>
      <TouchableOpacity 
        style={styles.taskContent} 
        onPress={() => toggleTaskCompletion(item.id, item.completed)} 
        onLongPress={() => navigation.navigate('EditTask', { taskId: item.id })} // Navigate to Edit on long press
      >
        <Text style={[styles.taskTitle, item.completed && styles.completedTask]}>
          {item.title}
        </Text>
        {item.description ? (
          <Text style={[styles.taskDescription, item.completed && styles.completedTask]}>
            {item.description}
          </Text>
        ) : null}
      </TouchableOpacity>
      <Button title="Excluir" color="red" onPress={() => deleteTask(item.id)} />
    </View>
  );

  return (
    <View style={styles.container}>
      <Button 
        title="Adicionar Nova Tarefa" 
        onPress={() => navigation.navigate('AddTask')} // Navigate to Add Task Screen
      />
      {tasks.length === 0 ? (
          <Text style={styles.noTasksText}>Nenhuma tarefa encontrada. Adicione uma!</Text>
      ) : (
          <FlatList
            data={tasks}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            style={styles.list}
          />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  loader: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  list: {
    marginTop: 10,
  },
  taskItem: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    marginVertical: 5,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#eee',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  taskContent: {
      flex: 1, // Take available space
      marginRight: 10, // Add some space before the button
  },
  taskTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  taskDescription: {
    fontSize: 14,
    color: 'gray',
    marginTop: 4,
  },
  completedTask: {
    textDecorationLine: 'line-through',
    color: 'gray',
  },
  noTasksText: {
      textAlign: 'center',
      marginTop: 50,
      fontSize: 16,
      color: 'grey',
  }
});

export default TaskListScreen;

