// src/screens/App/HomeScreen.js
// Placeholder for the main screen after login
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import auth from '@react-native-firebase/auth';

const HomeScreen = ({ navigation }) => {

  const handleLogout = async () => {
    try {
      await auth().signOut();
      console.log('Usuário deslogado!');
      // O RootNavigator cuidará de redirecionar para AuthNavigator
    } catch (error) {
      console.error('Erro ao fazer logout:', error);
      Alert.alert('Erro', 'Não foi possível fazer logout.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Tela Principal (Logado)</Text>
      <Text>Bem-vindo!</Text>
      {/* Aqui virão os componentes de Tarefas e Pomodoro */} 
      <Button title="Gerenciar Tarefas" onPress={() => navigation.navigate('TaskList')} />
      <Button title="Iniciar Pomodoro" onPress={() => navigation.navigate('Pomodoro')} />
      <View style={styles.logoutButtonContainer}>
        <Button title="Sair (Logout)" onPress={handleLogout} color="red" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  logoutButtonContainer: {
      marginTop: 30,
  }
});

export default HomeScreen;

