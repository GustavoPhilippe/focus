// src/screens/App/EditTaskScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import firestore from '@react-native-firebase/firestore';

const EditTaskScreen = ({ route, navigation }) => {
  const { taskId } = route.params; // Get taskId passed from navigation
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const subscriber = firestore()
      .collection('tasks')
      .doc(taskId)
      .onSnapshot(documentSnapshot => {
        if (documentSnapshot.exists) {
          const taskData = documentSnapshot.data();
          setTitle(taskData.title);
          setDescription(taskData.description || ''); // Handle cases where description might be undefined
          setLoading(false);
        } else {
          console.log('Tarefa não encontrada!');
          Alert.alert('Erro', 'Tarefa não encontrada.');
          navigation.goBack();
        }
      }, error => {
          console.error("Erro ao buscar tarefa para edição: ", error);
          Alert.alert("Erro", "Não foi possível carregar a tarefa para edição.");
          setLoading(false);
          navigation.goBack();
      });

    // Stop listening for updates when no longer required
    return () => subscriber();
  }, [taskId, navigation]);

  const handleUpdateTask = async () => {
    if (!title) {
      Alert.alert('Erro', 'O título da tarefa é obrigatório.');
      return;
    }
    setSaving(true);
    try {
      await firestore()
        .collection('tasks')
        .doc(taskId)
        .update({
          title,
          description,
          // You might want to add an updatedAt timestamp here as well
          // updatedAt: firestore.FieldValue.serverTimestamp(),
        });
      console.log('Tarefa atualizada com sucesso!');
      Alert.alert('Sucesso', 'Tarefa atualizada!');
      navigation.goBack(); // Go back to the task list
    } catch (error) {
      console.error("Erro ao atualizar tarefa: ", error);
      Alert.alert('Erro', 'Não foi possível atualizar a tarefa.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <ActivityIndicator size="large" style={styles.loader} />;
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Editar Tarefa</Text>
      <TextInput
        style={styles.input}
        placeholder="Título da Tarefa *"
        value={title}
        onChangeText={setTitle}
      />
      <TextInput
        style={[styles.input, styles.textArea]}
        placeholder="Descrição (Opcional)"
        value={description}
        onChangeText={setDescription}
        multiline
      />
      {saving ? (
          <ActivityIndicator size="large" />
      ) : (
          <Button title="Salvar Alterações" onPress={handleUpdateTask} />
      )}
      <View style={{ marginTop: 10 }}>
        <Button title="Cancelar" onPress={() => navigation.goBack()} color="gray" />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  loader: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 45,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 15,
    paddingHorizontal: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  textArea: {
      height: 100,
      textAlignVertical: 'top',
  }
});

export default EditTaskScreen;

