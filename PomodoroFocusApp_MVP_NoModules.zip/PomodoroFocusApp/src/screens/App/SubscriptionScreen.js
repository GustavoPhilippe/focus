// src/screens/App/SubscriptionScreen.js
import React from 'react';
import { View, Text, Button, StyleSheet, Alert } from 'react-native';
import { StripeProvider, useStripe } from '@stripe/stripe-react-native';

// !! IMPORTANTE !!
// Esta é uma tela placeholder para a funcionalidade de assinatura.
// A integração real com Stripe requer:
// 1. Configuração da sua chave publicável do Stripe abaixo.
// 2. Um backend para criar PaymentIntents ou configurar Assinaturas.
// 3. Lógica para lidar com o fluxo de pagamento (ex: presentPaymentSheet).

const STRIPE_PUBLISHABLE_KEY = "SUA_CHAVE_PUBLICAVEL_STRIPE_AQUI"; // Substitua pela sua chave!

const SubscriptionContent = ({ navigation }) => {
  const { initPaymentSheet, presentPaymentSheet } = useStripe();
  const [loading, setLoading] = React.useState(false);

  const initializePaymentSheet = async () => {
    // --- Lógica de Backend Necessária --- 
    // Aqui você chamaria seu backend para criar uma intenção de pagamento
    // ou configurar uma assinatura e obter o clientSecret, ephemeralKey e customerId.
    // Exemplo de dados FALSOS que viriam do backend:
    const fakeBackendResponse = {
        paymentIntentClientSecret: 'pi_fake_secret_123',
        ephemeralKeySecret: 'ek_fake_secret_456',
        customerId: 'cus_fake_789',
        publishableKey: STRIPE_PUBLISHABLE_KEY
    };
    // -------------------------------------

    if (!fakeBackendResponse.paymentIntentClientSecret) {
        Alert.alert("Erro", "Não foi possível obter os detalhes de pagamento do servidor. Verifique o backend.");
        return false;
    }

    const { error } = await initPaymentSheet({
      merchantDisplayName: "Pomodoro Focus App",
      customerId: fakeBackendResponse.customerId,
      customerEphemeralKeySecret: fakeBackendResponse.ephemeralKeySecret,
      paymentIntentClientSecret: fakeBackendResponse.paymentIntentClientSecret,
      // Defina allowsDelayedPaymentMethods como true se você quiser aceitar débitos bancários, etc.
      allowsDelayedPaymentMethods: true,
      // Adicione outras configurações conforme necessário (ex: defaultBillingDetails)
    });
    if (error) {
      Alert.alert(`Erro ao inicializar: ${error.code}`, error.message);
      console.error("Erro initPaymentSheet:", error);
      return false;
    } 
    return true;
  };

  const openPaymentSheet = async () => {
    setLoading(true);
    const initialized = await initializePaymentSheet();
    if (!initialized) {
        setLoading(false);
        return; // Sai se a inicialização falhou
    }

    const { error } = await presentPaymentSheet();

    if (error) {
      Alert.alert(`Erro ${error.code}`, error.message);
      console.error("Erro presentPaymentSheet:", error);
    } else {
      Alert.alert('Sucesso', 'Seu pagamento foi confirmado!');
      // Aqui você atualizaria o status da assinatura do usuário no Firestore/Backend
      // e talvez navegaria para uma tela de confirmação ou de volta para Home.
      // Ex: updateUserSubscriptionStatus(true);
      // navigation.navigate('Home');
    }
    setLoading(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Assinatura Premium</Text>
      <Text style={styles.description}>
        Desbloqueie todos os recursos com a assinatura mensal de R$9,90.
      </Text>
      <Text style={styles.warning}>
        (Nota: Esta é uma tela de exemplo. A integração real requer backend e chave Stripe válida.)
      </Text>
      <Button
        variant="primary"
        disabled={loading || !STRIPE_PUBLISHABLE_KEY.startsWith('pk_')}
        title={loading ? "Processando..." : "Assinar Agora (R$9,90/mês)"}
        onPress={openPaymentSheet}
      />
       <View style={{ marginTop: 10 }}>
         <Button title="Voltar" onPress={() => navigation.goBack()} color="gray" />
       </View>
    </View>
  );
}

// Componente Wrapper para o StripeProvider
const SubscriptionScreen = ({ navigation }) => {
    if (!STRIPE_PUBLISHABLE_KEY || !STRIPE_PUBLISHABLE_KEY.startsWith('pk_')) {
        return (
            <View style={styles.container}>
                <Text style={styles.title}>Configuração Pendente</Text>
                <Text style={styles.warning}>A chave publicável do Stripe não foi configurada corretamente no arquivo `src/screens/App/SubscriptionScreen.js`. Pagamentos desabilitados.</Text>
                <Button title="Voltar" onPress={() => navigation.goBack()} color="gray" />
            </View>
        );
    }

    return (
        <StripeProvider publishableKey={STRIPE_PUBLISHABLE_KEY}>
            <SubscriptionContent navigation={navigation} />
        </StripeProvider>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
    color: 'gray',
  },
  warning: {
      fontSize: 12,
      textAlign: 'center',
      marginBottom: 20,
      color: 'orange',
      fontStyle: 'italic',
  }
});

export default SubscriptionScreen;

