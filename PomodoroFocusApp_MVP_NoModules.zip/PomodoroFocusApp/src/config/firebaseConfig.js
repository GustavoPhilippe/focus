// src/config/firebaseConfig.js

// !! IMPORTANTE !!
// Este arquivo é um placeholder.
// Você precisa substituir os valores abaixo pelos dados reais do seu projeto Firebase.
// Obtenha essas informações no console do Firebase ao configurar seu aplicativo.

// Além disso, certifique-se de ter adicionado:
// 1. O arquivo `google-services.json` em `android/app/`
// 2. O arquivo `GoogleService-Info.plist` no seu projeto Xcode (para iOS)

const firebaseConfig = {
  apiKey: "SUA_API_KEY",
  authDomain: "SEU_AUTH_DOMAIN",
  projectId: "SEU_PROJECT_ID",
  storageBucket: "SEU_STORAGE_BUCKET",
  messagingSenderId: "SEU_MESSAGING_SENDER_ID",
  appId: "SEU_APP_ID",
  // measurementId: "SEU_MEASUREMENT_ID" // Opcional, para Google Analytics
};

export default firebaseConfig;

